default[:graylog][:email]  = "sunil.kumar@relevancelab.com"
default[:graylog][:password]  = "yourname"